# SHUI Converter

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/gOQQgqy/6cce71a9a4e6343be3d88d325298781a](https://codepen.io/Nalini1998/pen/gOQQgqy/6cce71a9a4e6343be3d88d325298781a).

# Gross Salary to SHUI Converter

A web application that calculates Social Health Insurance (SHUI) contributions based on the gross salary. This converter helps individuals and employers calculate the total SHUI contribution, as well as the breakdown of the employee's and employer's contributions to social insurance, unemployment insurance, and health insurance.

## Features

- Calculate total SHUI contribution based on the input of the gross salary
- Display the breakdown of the employee's and employer's contributions to social insurance, unemployment insurance, and health insurance

## How to Use

1. Enter the gross salary in VND in the "GROSS SALARY" input field.
2. The "TOTAL SHUI CONTRIBUTION" will be automatically calculated and displayed.
3. The "Employee's SHUI contribution" section will display the breakdown of the employee's contributions to social insurance, unemployment insurance, and health insurance.
4. The "Employer's SHUI contribution" section will display the breakdown of the employer's contributions to social insurance, unemployment insurance, and health insurance.

## Built With

- HTML
- CSS (W3.CSS)
- JavaScript (jQuery)
- Bootstrap (3.3.7)

## Author

- GitHub: [Meow.Nalini98](https://github.com/Nalini1998)

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details.